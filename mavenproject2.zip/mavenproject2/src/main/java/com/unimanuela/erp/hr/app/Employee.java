
package com.unimanuela.erp.hr.app;

import java.io.Serializable;
import java.util.Objects;

public class Employee implements Serializable {

    private String name;
    private String email;
    private String position;

    public Employee() {}

    public Employee(String name, String email, String position) {
        this.name = name;
        this.email = email;
        this.position = position;
    }

    // Getters y Setters
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }

    public String getPosition() { return position; }
    public void setPosition(String position) { this.position = position; }

    // Para que remove() funcione correctamente en listas
    @Override
    public boolean equals(Object o) {
        if(this == o) return true;
        if(!(o instanceof Employee)) return false;
        Employee e = (Employee) o;
        return Objects.equals(name, e.name) &&
               Objects.equals(email, e.email) &&
               Objects.equals(position, e.position);
    }

    @Override
    public int hashCode() {
        return Objects.hash(name, email, position);
    }
}
