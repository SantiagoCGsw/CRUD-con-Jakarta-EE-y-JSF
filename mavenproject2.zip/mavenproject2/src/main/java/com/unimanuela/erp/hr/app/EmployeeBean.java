
package com.unimanuela.erp.hr.app;

import jakarta.enterprise.context.SessionScoped;
import jakarta.inject.Inject;
import jakarta.inject.Named;
import java.io.Serializable;
import java.util.List;

@Named
@SessionScoped
public class EmployeeBean implements Serializable {

    private Employee newEmployee = new Employee();
    private Employee selectedEmployee;

    @Inject
    private EmployeeService employeeService;

    public Employee getNewEmployee() { return newEmployee; }
    public void setNewEmployee(Employee newEmployee) { this.newEmployee = newEmployee; }

    public Employee getSelectedEmployee() { return selectedEmployee; }
    public void setSelectedEmployee(Employee selectedEmployee) { this.selectedEmployee = selectedEmployee; }

    public void addEmployee() {
        employeeService.addEmployee(newEmployee);
        newEmployee = new Employee(); // limpiar formulario
    }

    public void deleteEmployee(Employee employee) {
        employeeService.removeEmployee(employee);
    }

    public void selectEmployee(Employee employee){
        this.selectedEmployee = employee;
    }

    public void updateEmployee(){
        if(selectedEmployee != null){
            // ya apunta a la instancia correcta, solo refresca la lista
            selectedEmployee = null; // limpiar selección
        }
    }

    public List<Employee> getEmployees() {
        return employeeService.getAllEmployees();
    }
}
